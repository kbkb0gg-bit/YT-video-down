
import React, { useEffect, useRef } from 'react';
import { PixelImage } from '../types';
import ImageCard from './ImageCard';

interface GalleryProps {
  images: PixelImage[];
  onImageClick: (img: PixelImage) => void;
  loading: boolean;
  hasMore: boolean;
  onLoadMore: () => void;
}

const Gallery: React.FC<GalleryProps> = ({ 
  images, onImageClick, loading, hasMore, onLoadMore 
}) => {
  const loaderRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loading) {
          onLoadMore();
        }
      },
      { threshold: 0.1 }
    );

    if (loaderRef.current) {
      observer.observe(loaderRef.current);
    }

    return () => observer.disconnect();
  }, [hasMore, loading, onLoadMore]);

  return (
    <div>
      <div className="masonry-grid">
        {images.map((image) => (
          <div key={image.id} className="masonry-item">
            <ImageCard 
              image={image} 
              onClick={() => onImageClick(image)} 
            />
          </div>
        ))}
      </div>

      <div ref={loaderRef} className="py-8 flex justify-center">
        {loading && (
          <div className="flex space-x-2 animate-pulse">
            <div className="w-3 h-3 bg-indigo-500 rounded-full"></div>
            <div className="w-3 h-3 bg-indigo-500 rounded-full"></div>
            <div className="w-3 h-3 bg-indigo-500 rounded-full"></div>
          </div>
        )}
        {!hasMore && images.length > 0 && (
          <p className="text-slate-400 text-sm italic">You've reached the end of the collection.</p>
        )}
      </div>
    </div>
  );
};

export default Gallery;
