
import React, { useState } from 'react';
import { PixelImage } from '../types';
import { storageService } from '../services/storageService';

interface ImageDetailModalProps {
  image: PixelImage;
  onClose: () => void;
  onDownload: () => void;
  onShare: () => void;
}

const ImageDetailModal: React.FC<ImageDetailModalProps> = ({ 
  image, onClose, onDownload, onShare 
}) => {
  const [copied, setCopied] = useState(false);

  const getSlug = (title: string) => {
    return title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  };

  const handleShareClick = () => {
    onShare();
    const shareUrl = `${window.location.host}/${getSlug(image.title)}`;
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 sm:p-8 bg-slate-900/95 backdrop-blur-md animate-in fade-in duration-300">
      <button 
        onClick={onClose}
        className="fixed top-6 right-6 z-50 p-2 text-white/70 hover:text-white transition-colors"
      >
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
      </button>

      <div className="bg-white rounded-3xl w-full max-w-6xl max-h-full overflow-hidden flex flex-col md:flex-row animate-in zoom-in-95 duration-300">
        
        {/* Visual Content */}
        <div className="md:w-3/5 lg:w-2/3 bg-slate-100 flex items-center justify-center overflow-hidden relative group">
          <img 
            src={image.url} 
            alt={image.title} 
            className="max-w-full max-h-[50vh] md:max-h-full object-contain"
          />
          <div className="absolute bottom-4 left-4 hidden md:block">
            <button 
              onClick={onDownload}
              className="px-6 py-3 bg-black/60 hover:bg-black/80 text-white backdrop-blur-md rounded-full text-sm font-bold transition-all flex items-center space-x-2 shadow-xl"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
              <span>Download High-Res</span>
            </button>
          </div>
        </div>

        {/* Sidebar Info */}
        <div className="md:w-2/5 lg:w-1/3 p-6 md:p-8 overflow-y-auto flex flex-col">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center space-x-3">
              <img src={image.userAvatar} className="w-12 h-12 rounded-full ring-2 ring-indigo-50" alt={image.username} />
              <div>
                <h4 className="font-bold text-slate-900">@{image.username}</h4>
                <p className="text-xs text-slate-500">Published {formatDate(image.createdAt)}</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <button 
                onClick={handleShareClick}
                className={`p-2.5 rounded-full transition-all duration-200 relative ${copied ? 'bg-green-100 text-green-600 ring-2 ring-green-200' : 'bg-slate-100 hover:bg-slate-200 text-slate-600'}`}
                title="Copy Link"
              >
                {copied ? (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
                ) : (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 100-2.684 3 3 0 000 2.684zm0 12a3 3 0 100-2.684 3 3 0 000 2.684z" /></svg>
                )}
                {copied && <span className="absolute -top-10 left-1/2 -translate-x-1/2 bg-green-600 text-white text-[10px] px-2 py-1 rounded-md font-bold whitespace-nowrap animate-bounce">Copied!</span>}
              </button>
              <button 
                onClick={onDownload}
                className="p-2.5 rounded-full bg-indigo-600 hover:bg-indigo-700 text-white transition-colors shadow-lg shadow-indigo-100"
                title="Download"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
              </button>
            </div>
          </div>

          <div className="flex-1">
            <h2 className="text-2xl font-black text-slate-900 mb-2 leading-tight">{image.title}</h2>
            <p className="text-slate-600 text-sm leading-relaxed mb-6">
              {image.description || 'No description provided.'}
            </p>

            <div className="flex flex-wrap gap-2 mb-8">
              {image.tags.map(tag => (
                <span key={tag} className="px-3 py-1 bg-slate-100 text-slate-600 text-[11px] font-bold uppercase tracking-wider rounded-lg hover:bg-indigo-50 hover:text-indigo-600 transition-colors cursor-pointer">
                  #{tag}
                </span>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-4 border-t border-slate-100 pt-6">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                <p className="text-[10px] uppercase tracking-widest font-black text-slate-400 mb-1">Total Views</p>
                <p className="text-xl font-black text-slate-800">{image.views.toLocaleString()}</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                <p className="text-[10px] uppercase tracking-widest font-black text-slate-400 mb-1">Downloads</p>
                <p className="text-xl font-black text-slate-800">{image.downloads.toLocaleString()}</p>
              </div>
            </div>

            <div className="mt-8 space-y-4">
              <div className="flex justify-between text-xs">
                <span className="font-bold text-slate-400 uppercase tracking-widest">Resolution</span>
                <span className="text-slate-700 font-bold">{image.metadata.width} × {image.metadata.height}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="font-bold text-slate-400 uppercase tracking-widest">File Size</span>
                <span className="text-slate-700 font-bold">{formatSize(image.metadata.size)}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="font-bold text-slate-400 uppercase tracking-widest">Format</span>
                <span className="text-slate-700 font-bold uppercase">{image.metadata.format}</span>
              </div>
            </div>
          </div>

          <div className="mt-auto pt-8 border-t border-slate-100">
            <button className="text-[10px] font-black text-slate-400 hover:text-red-500 uppercase tracking-widest flex items-center transition-colors">
              <svg className="w-4 h-4 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
              Report this content
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageDetailModal;
