
import React, { useState } from 'react';
import { User } from '../types';
import { storageService } from '../services/storageService';

interface AuthModalProps {
  onClose: () => void;
  onSuccess: (user: User) => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ onClose, onSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    email: 'alex@example.com',
    password: 'password123',
    username: ''
  });
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (isLogin) {
      const user = storageService.login(formData.email, formData.password);
      if (user) {
        onSuccess(user);
      } else {
        setError('Invalid email or password.');
      }
    } else {
      // Mock registration
      onSuccess(storageService.googleLogin({
        id: `g-${Date.now()}`,
        name: formData.username || 'New User',
        email: formData.email,
        picture: `https://picsum.photos/seed/${Date.now()}/200`
      }));
    }
  };

  const handleGoogleLogin = () => {
    // Mock Google OAuth redirect
    onSuccess(storageService.googleLogin({
      id: 'g-12345',
      name: 'Google User',
      email: 'google@gmail.com',
      picture: 'https://picsum.photos/seed/google/200'
    }));
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300">
        <div className="p-8">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center">
              <div className="bg-indigo-600 h-8 w-8 rounded-lg flex items-center justify-center mr-2">
                <span className="text-white font-bold text-xl">P</span>
              </div>
              <span className="text-xl font-bold text-slate-800">PixelShare</span>
            </div>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>

          <h2 className="text-2xl font-bold text-slate-800 mb-2">
            {isLogin ? 'Welcome back!' : 'Create an account'}
          </h2>
          <p className="text-slate-500 text-sm mb-8">
            {isLogin ? 'Log in to manage your high-res captures.' : 'Join the community and start sharing your art.'}
          </p>

          <button
            onClick={handleGoogleLogin}
            className="w-full flex items-center justify-center py-3 px-4 border border-slate-200 rounded-xl hover:bg-slate-50 transition-all font-medium text-slate-700 mb-6 shadow-sm"
          >
            <svg className="w-5 h-5 mr-3" viewBox="0 0 24 24">
              <path fill="#EA4335" d="M12 5.04c1.94 0 3.51.68 4.79 1.94l3.51-3.51C17.92 1.34 15.14 0 12 0 7.42 0 3.51 2.67 1.64 6.56l4.03 3.12C6.54 7.21 9.04 5.04 12 5.04z" />
              <path fill="#FBBC05" d="M23.51 12.24c0-.85-.07-1.68-.21-2.48H12v4.69h6.48c-.28 1.54-1.13 2.84-2.42 3.71l3.87 3c2.26-2.09 3.58-5.18 3.58-8.92z" />
              <path fill="#4285F4" d="M12 24c3.24 0 5.96-1.07 7.95-2.91l-3.87-3c-1.07.72-2.44 1.15-4.08 1.15-3.14 0-5.8-2.12-6.75-4.97L1.22 17.4C3.17 21.33 7.26 24 12 24z" />
              <path fill="#34A853" d="M5.25 14.27c-.24-.72-.37-1.48-.37-2.27 0-.79.13-1.55.37-2.27L1.22 6.61C.44 8.21 0 10.04 0 12s.44 3.79 1.22 5.39l4.03-3.12z" />
            </svg>
            Continue with Google
          </button>

          <div className="relative mb-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-100"></div>
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white px-3 text-slate-400">Or continue with email</span>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Username</label>
                <input
                  type="text"
                  required
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                />
              </div>
            )}
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Email address</label>
              <input
                type="email"
                required
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Password</label>
              <input
                type="password"
                required
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              />
            </div>

            {error && <p className="text-red-500 text-xs font-medium">{error}</p>}

            <button
              type="submit"
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-lg shadow-indigo-100 transition-all mt-4"
            >
              {isLogin ? 'Sign In' : 'Create Account'}
            </button>
          </form>

          <p className="text-center text-slate-500 text-sm mt-8">
            {isLogin ? "Don't have an account?" : 'Already have an account?'}
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="ml-2 text-indigo-600 font-bold hover:underline"
            >
              {isLogin ? 'Join now' : 'Sign in'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
