
import React, { useState } from 'react';
import { PixelImage } from '../types';
import { storageService } from '../services/storageService';

interface ImageCardProps {
  image: PixelImage;
  onClick: () => void;
}

const ImageCard: React.FC<ImageCardProps> = ({ image, onClick }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [copied, setCopied] = useState(false);

  const getSlug = (title: string) => {
    return title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  };

  const handleAction = (e: React.MouseEvent, action: string) => {
    e.stopPropagation();
    if (action === 'download') {
      storageService.incrementStats(image.id, 'download');
      const link = document.createElement('a');
      link.href = image.url;
      link.download = `${getSlug(image.title)}.jpg`;
      link.click();
    } else if (action === 'share') {
      storageService.incrementStats(image.id, 'share');
      const shareUrl = `${window.location.host}/${getSlug(image.title)}`;
      navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } else if (action === 'report') {
      const reason = prompt('Reason for reporting this image:');
      if (reason) storageService.reportImage(image.id, reason);
    }
    setShowMenu(false);
  };

  return (
    <div 
      className="relative group rounded-xl overflow-hidden bg-white cursor-pointer shadow-sm hover:shadow-xl transition-all duration-300 border border-slate-100"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => { setIsHovered(false); setShowMenu(false); }}
      onClick={onClick}
    >
      <div className="relative overflow-hidden">
        <img 
          src={image.thumbnailUrl} 
          alt={image.title}
          loading="lazy"
          className="w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        
        {/* Hover Actions Overlay (Top) */}
        <div className={`absolute top-0 left-0 right-0 p-3 flex justify-between items-start transition-opacity duration-300 ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
          <div className="flex items-center space-x-2 bg-black/20 backdrop-blur-md rounded-full px-2 py-1">
            <img src={image.userAvatar} className="w-6 h-6 rounded-full border border-white/20" alt={image.username} />
            <span className="text-white text-xs font-medium truncate max-w-[80px]">
              {image.username}
            </span>
          </div>
          <div className="relative">
            <button 
              onClick={(e) => { e.stopPropagation(); setShowMenu(!showMenu); }}
              className="p-1.5 rounded-full bg-black/20 hover:bg-black/40 text-white backdrop-blur-md transition-colors"
            >
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z" /></svg>
            </button>
            {showMenu && (
              <div className="absolute right-0 mt-2 w-32 bg-white rounded-lg shadow-xl py-1 z-10 border border-slate-100">
                <button 
                  onClick={(e) => handleAction(e, 'report')}
                  className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 font-medium"
                >
                  Report
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Persistent Footer */}
      <div className="p-3 bg-white border-t border-slate-50 flex items-center justify-between">
        <div className="flex-1 min-w-0 pr-2">
          <h3 className="text-sm font-semibold text-slate-800 truncate leading-tight mb-0.5">{image.title}</h3>
          <div className="flex items-center space-x-2 text-[10px] text-slate-400 font-medium">
            <span className="flex items-center">
              <svg className="w-3 h-3 mr-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
              {image.views}
            </span>
            <span className="flex items-center">
              <svg className="w-3 h-3 mr-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
              {image.downloads}
            </span>
          </div>
        </div>
        <div className="flex items-center space-x-1.5">
          <button 
            onClick={(e) => handleAction(e, 'share')}
            className={`p-2 rounded-lg transition-all duration-200 flex items-center ${copied ? 'bg-green-100 text-green-600 ring-1 ring-green-200' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            title="Copy Link"
          >
            {copied ? (
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
            ) : (
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 100-2.684 3 3 0 000 2.684zm0 12a3 3 0 100-2.684 3 3 0 000 2.684z" /></svg>
            )}
          </button>
          <button 
            onClick={(e) => handleAction(e, 'download')}
            className="p-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition-all shadow-sm"
            title="Download Image"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ImageCard;
