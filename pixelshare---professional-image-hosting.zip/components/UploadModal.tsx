
import React, { useState, useRef } from 'react';
import { PixelImage } from '../types';
import { storageService } from '../services/storageService';
import { analyzeImageWithAI } from '../services/geminiService';

interface UploadModalProps {
  onClose: () => void;
  onSuccess: (img: PixelImage) => void;
}

const UploadModal: React.FC<UploadModalProps> = ({ onClose, onSuccess }) => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    tags: ''
  });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (selected) processFile(selected);
  };

  const processFile = (selected: File) => {
    if (selected.size > 10 * 1024 * 1024) {
      alert('File size too large (max 10MB)');
      return;
    }
    setFile(selected);
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      setPreview(base64);
      // Auto-analyze with AI
      handleAIAnalysis(base64);
    };
    reader.readAsDataURL(selected);
  };

  const handleAIAnalysis = async (base64: string) => {
    setAnalyzing(true);
    const data = await analyzeImageWithAI(base64.split(',')[1]);
    if (data) {
      setFormData({
        title: data.title,
        description: data.description,
        tags: data.tags.join(', ')
      });
    }
    setAnalyzing(false);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const dropped = e.dataTransfer.files?.[0];
    if (dropped) processFile(dropped);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!preview) return;

    setUploading(true);
    // Simulate server processing
    await new Promise(r => setTimeout(r, 1500));

    const newImg = storageService.uploadImage({
      url: preview,
      title: formData.title,
      description: formData.description,
      tags: formData.tags.split(',').map(t => t.trim()).filter(t => t),
      metadata: {
        width: 1920, // Simulated
        height: 1080,
        size: file?.size || 0,
        format: file?.type.split('/')[1] || 'unknown'
      }
    });

    if (newImg) {
      onSuccess(newImg);
    }
    setUploading(false);
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden shadow-2xl flex flex-col md:flex-row animate-in zoom-in-95 duration-300">
        
        {/* Left Side: Upload Area */}
        <div 
          className="md:w-1/2 p-8 bg-slate-50 border-r border-slate-100 flex flex-col items-center justify-center relative min-h-[300px]"
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          {preview ? (
            <div className="relative w-full h-full flex flex-col items-center justify-center">
              <img src={preview} alt="Preview" className="max-w-full max-h-[400px] rounded-lg shadow-md object-contain" />
              <button 
                onClick={() => { setFile(null); setPreview(null); }}
                className="mt-4 text-sm text-red-500 hover:text-red-600 font-medium"
              >
                Remove and choose another
              </button>
            </div>
          ) : (
            <div 
              className="w-full h-full border-2 border-dashed border-slate-300 rounded-xl flex flex-col items-center justify-center p-12 text-center cursor-pointer hover:border-indigo-400 hover:bg-indigo-50/50 transition-all"
              onClick={() => fileInputRef.current?.click()}
            >
              <div className="w-16 h-16 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mb-4">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
              </div>
              <h3 className="text-lg font-semibold text-slate-800">Drag & drop image here</h3>
              <p className="text-slate-500 text-sm mt-2">Supports JPG, PNG, GIF, WebP up to 10MB</p>
              <button className="mt-6 px-6 py-2 bg-white border border-slate-200 rounded-lg text-sm font-medium hover:bg-slate-50 shadow-sm">
                Select from computer
              </button>
            </div>
          )}
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            accept="image/*" 
            className="hidden" 
          />
        </div>

        {/* Right Side: Metadata Form */}
        <div className="md:w-1/2 p-8 flex flex-col overflow-y-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-slate-800">Post details</h2>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 flex-1">
            {analyzing && (
              <div className="bg-indigo-50 border border-indigo-100 p-3 rounded-lg flex items-center mb-4 animate-pulse">
                <div className="w-4 h-4 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin mr-3"></div>
                <span className="text-sm text-indigo-700 font-medium">AI is generating details...</span>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Title</label>
              <input
                type="text"
                required
                className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                placeholder="Give your capture a name"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Description</label>
              <textarea
                rows={4}
                className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
                placeholder="Tell the story behind this image..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Tags (comma separated)</label>
              <input
                type="text"
                className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                placeholder="nature, sunset, macro..."
                value={formData.tags}
                onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
              />
            </div>

            <div className="pt-6 mt-auto">
              <button
                type="submit"
                disabled={!preview || uploading}
                className={`w-full py-3 rounded-xl font-bold text-white shadow-lg transition-all ${
                  !preview || uploading 
                    ? 'bg-slate-300 cursor-not-allowed' 
                    : 'bg-gradient-to-r from-indigo-600 to-violet-600 hover:shadow-indigo-200 hover:-translate-y-0.5'
                }`}
              >
                {uploading ? (
                  <span className="flex items-center justify-center">
                    <svg className="animate-spin h-5 w-5 mr-3 border-2 border-white border-t-transparent rounded-full" viewBox="0 0 24 24"></svg>
                    Processing Upload...
                  </span>
                ) : 'Publish to PixelShare'}
              </button>
              <p className="text-xs text-slate-400 text-center mt-4">
                By publishing, you agree to our Terms of Service and Privacy Policy.
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default UploadModal;
