
import React, { useState, useMemo } from 'react';
import { User, PixelImage } from '../types';
import { storageService } from '../services/storageService';
import Gallery from './Gallery';

interface ProfilePageProps {
  user: User;
  onImageClick: (img: PixelImage) => void;
  onUpdateProfile: (user: User) => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ user, onImageClick, onUpdateProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    username: user.username,
    bio: user.bio
  });

  const userImages = useMemo(() => storageService.getUserImages(user.id), [user.id]);

  const stats = useMemo(() => {
    return userImages.reduce((acc, img) => ({
      views: acc.views + img.views,
      downloads: acc.downloads + img.downloads,
      uploads: acc.uploads + 1
    }), { views: 0, downloads: 0, uploads: 0 });
  }, [userImages]);

  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = storageService.updateProfile(editData);
    if (updated) {
      onUpdateProfile(updated);
      setIsEditing(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto py-8">
      {/* Profile Header */}
      <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 mb-12">
        <div className="flex flex-col md:flex-row items-center md:items-start md:space-x-10">
          <div className="relative mb-6 md:mb-0">
            <img 
              src={user.profilePic} 
              alt={user.username} 
              className="w-32 h-32 rounded-full ring-4 ring-indigo-50 border-4 border-white shadow-xl" 
            />
            {isEditing && (
              <button className="absolute bottom-0 right-0 p-2 bg-indigo-600 text-white rounded-full shadow-lg">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
              </button>
            )}
          </div>

          <div className="flex-1 text-center md:text-left">
            {!isEditing ? (
              <>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                  <div>
                    <h1 className="text-3xl font-extrabold text-slate-900">@{user.username}</h1>
                    <p className="text-slate-500 font-medium">{user.email}</p>
                  </div>
                  <button 
                    onClick={() => setIsEditing(true)}
                    className="mt-4 md:mt-0 px-6 py-2 border border-slate-200 rounded-full font-bold text-slate-600 hover:bg-slate-50 transition-all"
                  >
                    Edit Profile
                  </button>
                </div>
                <p className="text-slate-600 max-w-2xl leading-relaxed mb-8">
                  {user.bio || 'This user hasn\'t written a bio yet.'}
                </p>
              </>
            ) : (
              <form onSubmit={handleUpdate} className="space-y-4 mb-8">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Username</label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                    value={editData.username}
                    onChange={(e) => setEditData({ ...editData, username: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Bio</label>
                  <textarea
                    rows={3}
                    className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
                    value={editData.bio}
                    onChange={(e) => setEditData({ ...editData, bio: e.target.value })}
                  />
                </div>
                <div className="flex space-x-3">
                  <button type="submit" className="px-6 py-2 bg-indigo-600 text-white rounded-full font-bold shadow-lg">Save Changes</button>
                  <button type="button" onClick={() => setIsEditing(false)} className="px-6 py-2 text-slate-500 font-bold">Cancel</button>
                </div>
              </form>
            )}

            {/* Stats Dashboard */}
            <div className="grid grid-cols-3 gap-4 md:gap-8 max-w-lg mx-auto md:mx-0">
              <div className="text-center md:text-left">
                <span className="block text-2xl font-black text-slate-900">{stats.uploads}</span>
                <span className="text-xs uppercase font-bold text-slate-400 tracking-widest">Images</span>
              </div>
              <div className="text-center md:text-left border-x border-slate-100 md:px-8">
                <span className="block text-2xl font-black text-slate-900">{stats.views.toLocaleString()}</span>
                <span className="text-xs uppercase font-bold text-slate-400 tracking-widest">Views</span>
              </div>
              <div className="text-center md:text-left">
                <span className="block text-2xl font-black text-slate-900">{stats.downloads.toLocaleString()}</span>
                <span className="text-xs uppercase font-bold text-slate-400 tracking-widest">Downloads</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* User Images */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Your Gallery</h2>
        {userImages.length > 0 ? (
          <Gallery 
            images={userImages} 
            onImageClick={onImageClick} 
            loading={false} 
            hasMore={false} 
            onLoadMore={() => {}} 
          />
        ) : (
          <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl py-20 text-center">
            <div className="text-6xl mb-4">🖼️</div>
            <h3 className="text-xl font-medium text-slate-600">No uploads yet</h3>
            <p className="text-slate-400 mt-2">Start sharing your high-resolution captures today!</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfilePage;
