
import { PixelImage, User, Activity, Report, AuthState } from '../types';
import { INITIAL_IMAGES, MOCK_USERS } from '../mockData';

class StorageService {
  private images: PixelImage[] = [];
  private users: User[] = [];
  private activities: Activity[] = [];
  private reports: Report[] = [];
  private currentUser: User | null = null;

  constructor() {
    this.init();
  }

  private init() {
    const savedImages = localStorage.getItem('pixel_images');
    const savedUsers = localStorage.getItem('pixel_users');
    const savedActivities = localStorage.getItem('pixel_activities');
    const savedAuth = localStorage.getItem('pixel_current_user');

    this.images = savedImages ? JSON.parse(savedImages) : INITIAL_IMAGES;
    this.users = savedUsers ? JSON.parse(savedUsers) : MOCK_USERS;
    this.activities = savedActivities ? JSON.parse(savedActivities) : [];
    this.currentUser = savedAuth ? JSON.parse(savedAuth) : null;

    if (!savedImages) this.persist();
  }

  private persist() {
    localStorage.setItem('pixel_images', JSON.stringify(this.images));
    localStorage.setItem('pixel_users', JSON.stringify(this.users));
    localStorage.setItem('pixel_activities', JSON.stringify(this.activities));
    localStorage.setItem('pixel_current_user', JSON.stringify(this.currentUser));
  }

  getImages(page: number = 1, limit: number = 12, search: string = '') {
    let filtered = [...this.images];
    if (search) {
      const s = search.toLowerCase();
      filtered = filtered.filter(img => 
        img.title.toLowerCase().includes(s) || 
        img.description.toLowerCase().includes(s) ||
        img.tags.some(t => t.toLowerCase().includes(s)) ||
        img.username.toLowerCase().includes(s)
      );
    }
    
    // Sort by latest by default
    filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const start = (page - 1) * limit;
    return {
      data: filtered.slice(start, start + limit),
      hasMore: start + limit < filtered.length
    };
  }

  getUserImages(userId: string) {
    return this.images.filter(img => img.userId === userId);
  }

  getCurrentUser() {
    return this.currentUser;
  }

  login(email: string, pass: string) {
    // Mock login
    const user = this.users.find(u => u.email === email);
    if (user) {
      this.currentUser = user;
      this.persist();
      return user;
    }
    return null;
  }

  googleLogin(googleData: any) {
    let user = this.users.find(u => u.googleId === googleData.id || u.email === googleData.email);
    if (!user) {
      user = {
        id: `u-${Date.now()}`,
        username: googleData.name.toLowerCase().replace(/\s/g, '_'),
        email: googleData.email,
        profilePic: googleData.picture,
        bio: 'New PixelShare user!',
        googleId: googleData.id,
        createdAt: new Date().toISOString()
      };
      this.users.push(user);
    }
    this.currentUser = user;
    this.persist();
    return user;
  }

  logout() {
    this.currentUser = null;
    this.persist();
  }

  uploadImage(imageData: Partial<PixelImage>) {
    if (!this.currentUser) return null;
    const newImage: PixelImage = {
      id: `img-${Date.now()}`,
      userId: this.currentUser.id,
      username: this.currentUser.username,
      userAvatar: this.currentUser.profilePic,
      url: imageData.url || '',
      thumbnailUrl: imageData.url || '',
      title: imageData.title || 'Untitled',
      description: imageData.description || '',
      tags: imageData.tags || [],
      views: 0,
      downloads: 0,
      shares: 0,
      createdAt: new Date().toISOString(),
      metadata: imageData.metadata || { width: 0, height: 0, size: 0, format: 'unknown' }
    };
    this.images.unshift(newImage);
    this.persist();
    return newImage;
  }

  incrementStats(imageId: string, type: 'view' | 'download' | 'share') {
    const img = this.images.find(i => i.id === imageId);
    if (img) {
      if (type === 'view') img.views++;
      if (type === 'download') img.downloads++;
      if (type === 'share') img.shares++;
      this.persist();
    }
  }

  reportImage(imageId: string, reason: string) {
    if (!this.currentUser) return;
    const report: Report = {
      id: `rep-${Date.now()}`,
      imageId,
      reporterId: this.currentUser.id,
      reason,
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    this.reports.push(report);
    // In a real app, this would be persisted to a secure table
    console.log('Report submitted:', report);
  }

  updateProfile(updates: Partial<User>) {
    if (!this.currentUser) return null;
    const userIndex = this.users.findIndex(u => u.id === this.currentUser?.id);
    if (userIndex !== -1) {
      this.users[userIndex] = { ...this.users[userIndex], ...updates };
      this.currentUser = this.users[userIndex];
      this.persist();
      return this.currentUser;
    }
    return null;
  }
}

export const storageService = new StorageService();
