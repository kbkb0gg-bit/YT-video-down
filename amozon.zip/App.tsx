
import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Home } from './pages/Home';
import { ProductDetail } from './pages/ProductDetail';
import { AdminLogin } from './pages/Admin/AdminLogin';
import { AdminDashboard } from './pages/Admin/AdminDashboard';
import { AdminForm } from './pages/Admin/AdminForm';

const App: React.FC = () => {
  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/product/:slug" element={<ProductDetail />} />
            
            {/* Admin Routes */}
            <Route path="/admin" element={<AdminLogin />} />
            <Route path="/admin/dashboard" element={<AdminDashboard />} />
            <Route path="/admin/add" element={<AdminForm />} />
            <Route path="/admin/edit/:id" element={<AdminForm />} />
          </Routes>
        </main>
        
        <footer className="bg-[#232f3e] text-white py-8 border-t border-gray-700">
          <div className="max-w-screen-xl mx-auto px-4 text-center">
            <div className="text-2xl font-bold italic mb-2 text-white">Amazon<span className="text-[#febd69]">Reviews</span></div>
            <p className="text-xs text-gray-400">&copy; 2024 Amazon Reviews Clone. All rights reserved. Amazon and the Amazon logo are trademarks of Amazon.com, Inc. or its affiliates.</p>
          </div>
        </footer>
      </div>
    </Router>
  );
};

export default App;
