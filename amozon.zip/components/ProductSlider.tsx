
import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { ProductImage } from '../types';

interface ProductSliderProps {
  images: ProductImage[];
}

export const ProductSlider: React.FC<ProductSliderProps> = ({ images }) => {
  const [activeIndex, setActiveIndex] = useState(0);

  const nextSlide = () => {
    setActiveIndex((prev) => (prev + 1) % images.length);
  };

  const prevSlide = () => {
    setActiveIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  if (!images || images.length === 0) return <div className="bg-gray-100 h-96 flex items-center justify-center">No images</div>;

  return (
    <div className="flex flex-col space-y-4">
      <div className="relative group">
        {/* Main Image View */}
        <div className="bg-white border rounded-lg overflow-hidden flex items-center justify-center h-[500px]">
          <img 
            src={images[activeIndex].url} 
            alt={images[activeIndex].alt}
            className="max-h-full max-w-full object-contain transition-transform duration-500 hover:scale-105 cursor-zoom-in"
          />
        </div>

        {/* Navigation Arrows */}
        <button 
          onClick={prevSlide}
          className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 p-2 rounded-full shadow-md hover:bg-white transition-opacity opacity-0 group-hover:opacity-100"
        >
          <ChevronLeft size={24} />
        </button>
        <button 
          onClick={nextSlide}
          className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 p-2 rounded-full shadow-md hover:bg-white transition-opacity opacity-0 group-hover:opacity-100"
        >
          <ChevronRight size={24} />
        </button>
      </div>

      {/* Thumbnail Strip */}
      <div className="flex space-x-2 overflow-x-auto no-scrollbar py-2">
        {images.map((img, idx) => (
          <button
            key={img.id}
            onClick={() => setActiveIndex(idx)}
            className={`flex-shrink-0 w-16 h-16 border-2 rounded-md overflow-hidden transition-all ${
              activeIndex === idx ? 'border-[#e77600] ring-2 ring-[#e77600]/20' : 'border-gray-200 hover:border-[#e77600]'
            }`}
          >
            <img src={img.url} alt={img.alt} className="w-full h-full object-cover" />
          </button>
        ))}
      </div>
    </div>
  );
};
