
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, ShoppingCart, Menu, MapPin, ChevronDown } from 'lucide-react';
import { mockDb } from '../mockDb';
import { Category } from '../types';

export const Navbar: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    setCategories(mockDb.getCategories());
  }, []);

  return (
    <header className="bg-[#131921] text-white">
      {/* Top Bar */}
      <div className="flex items-center p-2 space-x-4 max-w-screen-2xl mx-auto">
        {/* Logo */}
        <Link to="/" className="flex items-center px-2 py-1 border border-transparent hover:border-white rounded-sm transition-colors">
          <div className="text-2xl font-bold italic">Amazon<span className="text-[#febd69]">Reviews</span></div>
        </Link>

        {/* Deliver To */}
        <div className="hidden md:flex flex-col px-2 py-1 border border-transparent hover:border-white rounded-sm cursor-pointer">
          <span className="text-xs text-gray-300">Deliver to</span>
          <div className="flex items-center font-bold">
            <MapPin size={16} className="mr-1" />
            <span className="text-sm">Global</span>
          </div>
        </div>

        {/* Search Bar */}
        <div className="flex-grow flex items-center h-10 bg-white rounded-md overflow-hidden group focus-within:ring-2 focus-within:ring-[#febd69]">
          <button className="bg-gray-100 text-gray-700 text-xs px-3 h-full border-r flex items-center hover:bg-gray-200">
            All <ChevronDown size={14} className="ml-1" />
          </button>
          <input 
            type="text" 
            className="flex-grow px-3 text-black text-sm focus:outline-none" 
            placeholder="Search Amazon Reviews..."
          />
          <button className="bg-[#febd69] hover:bg-[#f3a847] p-2 h-full text-[#131921]">
            <Search size={22} />
          </button>
        </div>

        {/* Right Nav Items */}
        <div className="hidden md:flex items-center space-x-1">
          <div className="px-2 py-1 border border-transparent hover:border-white rounded-sm cursor-pointer">
            <span className="text-xs text-gray-300">Hello, Sign in</span>
            <div className="flex items-center font-bold text-sm">Account & Lists <ChevronDown size={14} /></div>
          </div>
          <div className="px-2 py-1 border border-transparent hover:border-white rounded-sm cursor-pointer">
            <span className="text-xs text-gray-300">Returns</span>
            <div className="font-bold text-sm">& Orders</div>
          </div>
          <Link to="/admin" className="px-2 py-1 border border-transparent hover:border-white rounded-sm cursor-pointer">
            <span className="text-xs text-gray-300">Admin</span>
            <div className="font-bold text-sm">Dashboard</div>
          </Link>
          <div className="flex items-center px-2 py-1 border border-transparent hover:border-white rounded-sm cursor-pointer relative">
            <ShoppingCart className="mr-1" />
            <span className="font-bold text-sm mt-2">Cart</span>
            <span className="absolute top-0 right-7 bg-[#febd69] text-[#131921] rounded-full text-xs px-1.5 font-bold">0</span>
          </div>
        </div>
      </div>

      {/* Sub Nav - Categories Only */}
      <div className="bg-[#232f3e] p-2 flex items-center space-x-4 text-sm font-medium overflow-x-auto no-scrollbar">
        <button className="flex items-center hover:border-white border border-transparent px-2 py-1 whitespace-nowrap">
          <Menu size={20} className="mr-1" /> All Categories
        </button>
        {categories.map((category) => (
          <Link 
            key={category.id} 
            to={`/?category=${category.slug}`}
            className="hover:border-white border border-transparent px-2 py-1 cursor-pointer whitespace-nowrap"
          >
            {category.name}
          </Link>
        ))}
      </div>
    </header>
  );
};
