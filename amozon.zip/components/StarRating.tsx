
import React from 'react';
import { Star, StarHalf } from 'lucide-react';

interface StarRatingProps {
  rating: number;
  size?: number;
  showText?: boolean;
}

export const StarRating: React.FC<StarRatingProps> = ({ rating, size = 20, showText = true }) => {
  const fullStars = Math.floor(rating);
  const hasHalf = rating % 1 !== 0;

  return (
    <div className="flex items-center">
      <div className="flex text-[#ffa41c]">
        {[...Array(fullStars)].map((_, i) => (
          <Star key={i} size={size} fill="currentColor" />
        ))}
        {hasHalf && <StarHalf size={size} fill="currentColor" />}
        {[...Array(5 - Math.ceil(rating))].map((_, i) => (
          <Star key={i} size={size} />
        ))}
      </div>
      {showText && (
        <span className="ml-2 text-sm text-[#007185] hover:text-[#c7511f] cursor-pointer font-medium">
          {rating} out of 5
        </span>
      )}
    </div>
  );
};
