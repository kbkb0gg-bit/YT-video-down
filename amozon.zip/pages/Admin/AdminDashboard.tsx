
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { mockDb } from '../../mockDb';
import { Product } from '../../types';
import { Plus, Edit, Trash2, Eye, Search } from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [search, setSearch] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const session = localStorage.getItem('admin_session');
    if (!session) navigate('/admin');
    setProducts(mockDb.getProducts());
  }, [navigate]);

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      mockDb.deleteProduct(id);
      setProducts(mockDb.getProducts());
    }
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) || 
    p.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-screen-xl mx-auto p-4 md:p-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          <p className="text-gray-600">Manage your product reviews and uploads</p>
        </div>
        <Link to="/admin/add" className="bg-blue-600 text-white px-4 py-2 rounded flex items-center hover:bg-blue-700 transition-colors">
          <Plus size={20} className="mr-2" /> Add New Review
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded shadow border-l-4 border-blue-500">
          <span className="text-gray-500 text-sm font-medium">Total Products</span>
          <div className="text-3xl font-bold mt-1">{products.length}</div>
        </div>
        <div className="bg-white p-6 rounded shadow border-l-4 border-green-500">
          <span className="text-gray-500 text-sm font-medium">Published Reviews</span>
          <div className="text-3xl font-bold mt-1">{products.filter(p => p.status === 'publish').length}</div>
        </div>
        <div className="bg-white p-6 rounded shadow border-l-4 border-orange-500">
          <span className="text-gray-500 text-sm font-medium">Drafts</span>
          <div className="text-3xl font-bold mt-1">{products.filter(p => p.status === 'draft').length}</div>
        </div>
      </div>

      <div className="bg-white rounded shadow border overflow-hidden">
        <div className="p-4 border-b flex items-center bg-gray-50">
          <div className="relative flex-grow max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Search products..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50 text-gray-700 text-sm">
              <tr>
                <th className="px-6 py-4">Product</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Rating</th>
                <th className="px-6 py-4">Created</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y text-sm">
              {filteredProducts.map(product => (
                <tr key={product.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <img src={product.images[0]?.url} className="w-10 h-10 object-cover rounded mr-3 bg-gray-100" />
                      <div>
                        <div className="font-bold">{product.name}</div>
                        <div className="text-gray-500 text-xs line-clamp-1">{product.title}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                      product.status === 'publish' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'
                    }`}>
                      {product.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4 font-medium">{product.rating} / 5</td>
                  <td className="px-6 py-4 text-gray-500">{new Date(product.createdAt).toLocaleDateString()}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end space-x-3">
                      <Link to={`/product/${product.slug}`} className="text-gray-500 hover:text-blue-600"><Eye size={18} /></Link>
                      <Link to={`/admin/edit/${product.id}`} className="text-gray-500 hover:text-green-600"><Edit size={18} /></Link>
                      <button onClick={() => handleDelete(product.id)} className="text-gray-500 hover:text-red-600"><Trash2 size={18} /></button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredProducts.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-10 text-center text-gray-500">No products found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
