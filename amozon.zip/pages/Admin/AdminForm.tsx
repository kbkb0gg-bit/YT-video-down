
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { mockDb } from '../../mockDb';
import { Product, ProductImage, Category } from '../../types';
import { X, Upload, Save, ArrowLeft } from 'lucide-react';

export const AdminForm: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [categories] = useState<Category[]>(mockDb.getCategories());
  
  const [formData, setFormData] = useState<Partial<Product>>({
    name: '',
    title: '',
    fullReview: '',
    rating: 5,
    categoryId: '1',
    amazonLink: '',
    price: 0,
    isFeatured: false,
    status: 'draft',
    images: [],
  });

  useEffect(() => {
    const session = localStorage.getItem('admin_session');
    if (!session) navigate('/admin');

    if (id) {
      const existing = mockDb.getProducts().find(p => p.id === id);
      if (existing) setFormData(existing);
    }
  }, [id, navigate]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const val = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    setFormData(prev => ({ ...prev, [name]: val }));
  };

  // Fixed the unknown type error by explicitly casting Array.from result to File[]
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const newImages: ProductImage[] = (Array.from(files) as File[]).map((file, idx) => ({
        id: Math.random().toString(36).substr(2, 9),
        url: URL.createObjectURL(file), // Using local blobs for demo
        alt: file.name,
        isFeatured: idx === 0 && (formData.images?.length === 0)
      }));
      setFormData(prev => ({ ...prev, images: [...(prev.images || []), ...newImages] }));
    }
  };

  const removeImage = (imgId: string) => {
    setFormData(prev => ({ ...prev, images: prev.images?.filter(img => img.id !== imgId) }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.title || !formData.images?.length) {
      alert('Please fill in required fields and upload at least one image.');
      return;
    }

    const slug = formData.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    
    const productData: Product = {
      ...(formData as Product),
      id: id || Math.random().toString(36).substr(2, 9),
      slug,
      createdAt: formData.createdAt || new Date().toISOString(),
    };

    if (id) {
      mockDb.updateProduct(productData);
    } else {
      mockDb.addProduct(productData);
    }
    navigate('/admin/dashboard');
  };

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-8">
      <button onClick={() => navigate('/admin/dashboard')} className="flex items-center text-blue-600 mb-6 hover:underline">
        <ArrowLeft size={20} className="mr-1" /> Back to Dashboard
      </button>
      
      <div className="bg-white p-6 md:p-8 rounded shadow border">
        <h1 className="text-2xl font-bold mb-8">{id ? 'Edit Review' : 'Add New Product Review'}</h1>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Product Name *</label>
                <input 
                  type="text" name="name" required value={formData.name} onChange={handleChange}
                  className="w-full px-3 py-2 border rounded focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  placeholder="e.g. Sony WH-1000XM5"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Review Title / Headline *</label>
                <input 
                  type="text" name="title" required value={formData.title} onChange={handleChange}
                  className="w-full px-3 py-2 border rounded focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  placeholder="e.g. The Best Noise Cancelling Headphones in 2024"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Rating (1-5)</label>
                  <select 
                    name="rating" value={formData.rating} onChange={handleChange}
                    className="w-full px-3 py-2 border rounded focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  >
                    {[1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5].map(r => <option key={r} value={r}>{r} Stars</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Category</label>
                  <select 
                    name="categoryId" value={formData.categoryId} onChange={handleChange}
                    className="w-full px-3 py-2 border rounded focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  >
                    {categories.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                  </select>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Price ($)</label>
                <input 
                  type="number" name="price" value={formData.price} onChange={handleChange}
                  className="w-full px-3 py-2 border rounded focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  placeholder="0.00"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Amazon Affiliate Link</label>
                <input 
                  type="url" name="amazonLink" value={formData.amazonLink} onChange={handleChange}
                  className="w-full px-3 py-2 border rounded focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  placeholder="https://amazon.com/..."
                />
              </div>
              <div className="flex items-center space-x-6 pt-2">
                <label className="flex items-center cursor-pointer">
                  <input 
                    type="checkbox" name="isFeatured" checked={formData.isFeatured} onChange={handleChange}
                    className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500 mr-2"
                  />
                  <span className="text-sm">Featured Product</span>
                </label>
                <label className="flex items-center cursor-pointer">
                  <select 
                    name="status" value={formData.status} onChange={handleChange}
                    className="px-2 py-1 border rounded text-sm focus:outline-none"
                  >
                    <option value="draft">Draft</option>
                    <option value="publish">Published</option>
                  </select>
                </label>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Full Review Content (HTML supported) *</label>
            <textarea 
              name="fullReview" required rows={10} value={formData.fullReview} onChange={handleChange}
              className="w-full px-3 py-2 border rounded focus:ring-1 focus:ring-blue-500 focus:outline-none font-sans"
              placeholder="Write your detailed review here. You can use <p>, <b>, <ul>, etc."
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-3">Product Images (Min 5 recommended) *</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
              {formData.images?.map(img => (
                <div key={img.id} className="relative aspect-square border rounded overflow-hidden group">
                  <img src={img.url} className="w-full h-full object-cover" />
                  <button 
                    type="button" 
                    onClick={() => removeImage(img.id)}
                    className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X size={14} />
                  </button>
                </div>
              ))}
              <label className="aspect-square border-2 border-dashed rounded flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 transition-colors">
                <Upload size={24} className="text-gray-400 mb-1" />
                <span className="text-xs text-gray-500">Upload</span>
                <input type="file" multiple accept="image/*" onChange={handleImageUpload} className="hidden" />
              </label>
            </div>
          </div>

          <div className="pt-6 border-t flex justify-end">
            <button 
              type="submit"
              className="bg-blue-600 text-white px-8 py-3 rounded-lg font-bold flex items-center hover:bg-blue-700 transition-colors shadow-lg"
            >
              <Save size={20} className="mr-2" /> {id ? 'Update Review' : 'Save Review'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
