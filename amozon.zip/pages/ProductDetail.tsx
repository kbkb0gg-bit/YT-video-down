
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { mockDb } from '../mockDb';
import { Product } from '../types';
import { ProductSlider } from '../components/ProductSlider';
import { StarRating } from '../components/StarRating';
import { ExternalLink, Check, ShieldCheck } from 'lucide-react';

export const ProductDetail: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [product, setProduct] = useState<Product | null>(null);

  useEffect(() => {
    if (slug) {
      const p = mockDb.getProductBySlug(slug);
      if (p) setProduct(p);
    }
  }, [slug]);

  if (!product) return <div className="p-20 text-center">Product not found.</div>;

  return (
    <div className="max-w-screen-xl mx-auto px-4 py-8 bg-white min-h-screen">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
        {/* Left Column: Image Slider */}
        <div className="lg:sticky lg:top-8 self-start">
          <ProductSlider images={product.images} />
        </div>

        {/* Right Column: Product Info */}
        <div className="flex flex-col space-y-4">
          <nav className="text-sm text-[#565959]">
            <Link to="/" className="hover:underline">Home</Link> &rsaquo; 
            <span className="ml-1">{product.categoryId}</span>
          </nav>

          <h1 className="text-2xl md:text-3xl font-medium leading-snug">{product.title}</h1>
          <p className="text-lg font-bold text-[#007185] hover:text-[#c7511f] cursor-pointer">Visit the Store</p>
          
          <div className="flex items-center space-x-4 border-b pb-4">
            <StarRating rating={product.rating} />
            <span className="text-[#007185] hover:text-[#c7511f] text-sm cursor-pointer border-l pl-4">84 ratings</span>
            <span className="text-[#007185] hover:text-[#c7511f] text-sm cursor-pointer border-l pl-4">12 answered questions</span>
          </div>

          <div className="py-2">
            <div className="flex items-baseline space-x-2">
              <span className="text-sm text-red-600 font-medium">-25%</span>
              <span className="text-2xl font-semibold font-serif">$<span className="text-4xl">{Math.floor(product.price || 0)}</span><sup>{(product.price || 0).toFixed(2).split('.')[1]}</sup></span>
            </div>
            <p className="text-xs text-gray-500">Typical price: <span className="line-through">{( (product.price || 0) * 1.33 ).toFixed(2)}</span></p>
          </div>

          <div className="bg-[#f0f2f2] p-4 rounded-lg space-y-4">
            <div className="flex items-center text-sm font-bold text-green-700">
              <Check size={18} className="mr-1" /> In Stock
            </div>
            <a 
              href={product.amazonLink} 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center space-x-2 amazon-btn-secondary py-2.5 rounded-full shadow border border-[#ff8f00] text-sm font-bold"
            >
              <span>Buy on Amazon</span>
              <ExternalLink size={16} />
            </a>
            <div className="flex items-center space-x-2 text-xs text-[#565959]">
                <ShieldCheck size={14} />
                <span>Secure transaction</span>
            </div>
          </div>

          <div className="space-y-2 pt-4 border-t">
            <h3 className="font-bold text-sm">About this item</h3>
            <ul className="list-disc pl-5 text-sm space-y-2 text-[#0f1111]">
                <li>High quality {product.name} with premium features.</li>
                <li>Expertly reviewed and tested for durability and performance.</li>
                <li>Multiple accessories included in the original packaging.</li>
                <li>Official manufacturer warranty supported via Amazon.</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Review Section */}
      <div className="max-w-4xl border-t pt-10">
        <h2 className="text-2xl font-bold mb-6">Detailed Review</h2>
        <div 
          className="prose prose-blue max-w-none text-[#0f1111] leading-relaxed space-y-4"
          dangerouslySetInnerHTML={{ __html: product.fullReview }}
        />
      </div>

      {/* Gallery */}
      <div className="mt-16 border-t pt-10">
        <h2 className="text-2xl font-bold mb-6">Product Gallery</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {product.images.map(img => (
                <div key={img.id} className="aspect-square bg-[#f0f2f2] rounded overflow-hidden cursor-pointer hover:opacity-80 transition-opacity">
                    <img src={img.url} alt={img.alt} className="w-full h-full object-cover" />
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};
