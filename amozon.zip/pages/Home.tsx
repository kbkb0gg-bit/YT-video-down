
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { mockDb } from '../mockDb';
import { Product } from '../types';
import { StarRating } from '../components/StarRating';

export const Home: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    setProducts(mockDb.getProducts().filter(p => p.status === 'publish'));
  }, []);

  return (
    <div className="max-w-screen-2xl mx-auto px-4 py-8">
      {/* Hero Banner */}
      <div className="relative h-96 bg-[#232f3e] rounded-md mb-8 overflow-hidden">
        <img 
          src="https://picsum.photos/seed/tech/1600/400" 
          alt="Featured Reviews"
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 flex flex-col justify-center px-12 text-white">
          <h1 className="text-4xl font-bold mb-4">Honest Product Reviews</h1>
          <p className="text-xl max-w-lg mb-6">Expert testing, detailed analysis, and affiliate links to the best products on Amazon.</p>
          <button className="bg-[#febd69] text-[#131921] px-6 py-2 rounded-md font-bold w-fit hover:bg-[#f3a847]">Browse Latest</button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {products.length > 0 ? (
          products.map(product => (
            <Link key={product.id} to={`/product/${product.slug}`} className="bg-white p-4 rounded-md shadow hover:shadow-lg transition-shadow flex flex-col group">
              <div className="h-56 mb-4 flex items-center justify-center overflow-hidden">
                <img 
                  src={product.images[0]?.url || 'https://picsum.photos/seed/placeholder/300/300'} 
                  alt={product.name}
                  className="max-h-full max-w-full object-contain group-hover:scale-105 transition-transform"
                />
              </div>
              <h3 className="font-bold text-lg mb-1 line-clamp-1 group-hover:text-[#007185]">{product.name}</h3>
              <p className="text-sm text-gray-600 mb-2 line-clamp-1">{product.title}</p>
              <div className="mb-2">
                <StarRating rating={product.rating} size={16} showText={false} />
              </div>
              <p className="text-sm text-gray-700 line-clamp-3 mb-4 flex-grow">
                {product.fullReview.replace(/<[^>]*>?/gm, '').substring(0, 120)}...
              </p>
              <div className="flex items-center justify-between">
                {product.price && <span className="text-xl font-bold font-serif">${product.price}</span>}
                <button className="amazon-btn-primary px-4 py-1.5 rounded-full text-sm font-medium shadow-sm border border-[#fcd200]">
                  Read Review
                </button>
              </div>
            </Link>
          ))
        ) : (
          <div className="col-span-full py-20 text-center">
            <h2 className="text-2xl font-bold text-gray-500">No reviews found yet.</h2>
            <p className="text-gray-400 mt-2">Go to the Admin panel to add your first product review!</p>
          </div>
        )}
      </div>
    </div>
  );
};
