
import { Product, Category } from './types';

const INITIAL_CATEGORIES: Category[] = [
  { id: '1', name: 'Electronics', slug: 'electronics' },
  { id: '2', name: 'Home & Kitchen', slug: 'home-kitchen' },
  { id: '3', name: 'Beauty', slug: 'beauty' },
];

const STORAGE_KEYS = {
  PRODUCTS: 'amz_rev_products',
  CATEGORIES: 'amz_rev_categories',
};

export const mockDb = {
  getProducts: (): Product[] => {
    const data = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
    return data ? JSON.parse(data) : [];
  },
  
  saveProducts: (products: Product[]) => {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
  },

  getCategories: (): Category[] => {
    const data = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    return data ? JSON.parse(data) : INITIAL_CATEGORIES;
  },

  addProduct: (product: Product) => {
    const products = mockDb.getProducts();
    products.push(product);
    mockDb.saveProducts(products);
  },

  updateProduct: (updatedProduct: Product) => {
    const products = mockDb.getProducts().map(p => p.id === updatedProduct.id ? updatedProduct : p);
    mockDb.saveProducts(products);
  },

  deleteProduct: (id: string) => {
    const products = mockDb.getProducts().filter(p => p.id !== id);
    mockDb.saveProducts(products);
  },

  getProductBySlug: (slug: string): Product | undefined => {
    return mockDb.getProducts().find(p => p.slug === slug);
  }
};
