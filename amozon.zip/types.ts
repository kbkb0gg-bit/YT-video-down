
export interface ProductImage {
  id: string;
  url: string;
  isFeatured: boolean;
  alt: string;
}

export interface Product {
  id: string;
  name: string;
  title: string;
  fullReview: string;
  rating: number;
  categoryId: string;
  amazonLink: string;
  price?: number;
  isFeatured: boolean;
  status: 'publish' | 'draft';
  slug: string;
  createdAt: string;
  images: ProductImage[];
  metaTitle?: string;
  metaDescription?: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
}

export interface AuthState {
  isLoggedIn: boolean;
  user: string | null;
}
